package com.company;

public class User {

    protected String name;

    public User(String name) {
        this.name = name;
    }
}
