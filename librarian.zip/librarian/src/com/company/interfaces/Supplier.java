package com.company.interfaces;

import com.company.Book;

public interface Supplier {
    Book[] sendBook(String name);

}
