package com.company.interfaces;

public interface Librarian {

    void order(Supplier supplier, String name);
}
